package cl.clicktv.player

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IVLCVout
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Locale
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    companion object {
        const val PREFS = "clicktv_player_settings"
        const val KEY_URL = "source_url"
        const val KEY_TYPE = "source_type"
        const val KEY_AUTOSTART = "autostart"
        const val KEY_PIN = "admin_pin"
        const val KEY_DELAY = "message_delay"
        const val KEY_CROP = "crop_video"
        const val DEFAULT_URL = "https://andromeda2.cd-latam.com:1936/Monitoreo_ClickTV/clicktv.stream/playlist.m3u8"
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var overlay: LinearLayout
    private lateinit var statusText: TextView
    private var libVLC: LibVLC? = null
    private var player: MediaPlayer? = null
    private var retryRunnable: Runnable? = null
    private var overlayRunnable: Runnable? = null
    private var retryCount = 0
    private var isPlaying = false
    private var settingsOpen = false
    private var lastUrl = ""
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()
        buildPlayerView()
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        lastUrl = prefs.getString(KEY_URL, DEFAULT_URL) ?: DEFAULT_URL
        if (lastUrl.isBlank()) lastUrl = DEFAULT_URL
        // Persist the supplied ClickTv HLS source as the initial default.
        if (prefs.getString(KEY_URL, null).isNullOrBlank()) {
            prefs.edit().putString(KEY_URL, DEFAULT_URL).putString(KEY_TYPE, "HLS").apply()
        }
        startPlayback()
        registerNetworkListener()
    }

    private fun enterImmersive() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        supportActionBar?.hide()
    }

    private fun buildPlayerView() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        videoLayout = VLCVideoLayout(this)
        root.addView(videoLayout, FrameLayout.LayoutParams(-1, -1))
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            setPadding(32, 24, 32, 24)
        }
        val title = TextView(this).apply {
            text = "PRONTO VOLVEMOS"
            setTextColor(Color.WHITE)
            textSize = 32f
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        statusText = TextView(this).apply {
            text = "Estamos experimentando un problema con la señal de origen."
            setTextColor(Color.LTGRAY)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 0)
        }
        overlay.addView(title)
        overlay.addView(statusText)
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        // Long press / Menu key opens the protected settings panel.
        root.setOnLongClickListener { askForPin(); true }
    }

    private fun initVlc() {
        if (libVLC != null && player != null) return
        val options = arrayListOf("--no-video-title-show", "--network-caching=1500", "--live-caching=1500", "--clock-jitter=0", "--clock-synchro=0")
        libVLC = LibVLC(this, options)
        player = MediaPlayer(libVLC).also { mp ->
            mp.attachViews(videoLayout, null, false, false)
            mp.setEventListener { event ->
                when (event.type) {
                    MediaPlayer.Event.Playing -> onPlaybackStarted()
                    MediaPlayer.Event.Buffering -> if (event.buffering >= 100f && !isPlaying) scheduleProblemOverlay()
                    MediaPlayer.Event.EncounteredError, MediaPlayer.Event.Stopped, MediaPlayer.Event.EndReached -> onPlaybackFailed()
                    else -> Unit
                }
            }
        }
    }

    private fun startPlayback() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val url = prefs.getString(KEY_URL, DEFAULT_URL)?.trim().orEmpty()
        if (url.isBlank()) { showSettings(firstRun = true); return }
        lastUrl = url
        cancelRetry()
        hideProblemOverlay()
        isPlaying = false
        try {
            initVlc()
            val media = Media(libVLC, android.net.Uri.parse(url)).apply {
                setHWDecoderEnabled(true, false)
                addOption(":no-video-title-show")
                addOption(":network-caching=1500")
                addOption(":live-caching=1500")
                val crop = prefs.getBoolean(KEY_CROP, false)
                if (crop) addOption(":aspect-ratio=16:9")
            }
            player?.media = media
            media.release()
            player?.play()
            scheduleProblemOverlay()
        } catch (_: Exception) {
            onPlaybackFailed()
        }
    }

    private fun onPlaybackStarted() {
        isPlaying = true
        retryCount = 0
        hideProblemOverlay()
        cancelRetry()
        enterImmersive()
    }

    private fun onPlaybackFailed() {
        isPlaying = false
        scheduleProblemOverlay()
        scheduleRetry()
    }

    private fun scheduleProblemOverlay() {
        overlayRunnable?.let { handler.removeCallbacks(it) }
        val delaySeconds = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_DELAY, 5).coerceIn(1, 120)
        overlayRunnable = Runnable {
            if (!isPlaying) {
                overlay.visibility = View.VISIBLE
                enterImmersive()
            }
        }
        handler.postDelayed(overlayRunnable!!, delaySeconds * 1000L)
    }

    private fun hideProblemOverlay() {
        overlayRunnable?.let { handler.removeCallbacks(it) }
        overlayRunnable = null
        overlay.visibility = View.GONE
    }

    private fun scheduleRetry() {
        if (retryRunnable != null) return
        val seconds = min(30, 2 shl retryCount.coerceAtMost(4))
        retryCount = (retryCount + 1).coerceAtMost(5)
        retryRunnable = Runnable {
            retryRunnable = null
            if (!settingsOpen) startPlayback()
        }
        handler.postDelayed(retryRunnable!!, seconds * 1000L)
    }

    private fun cancelRetry() {
        retryRunnable?.let { handler.removeCallbacks(it) }
        retryRunnable = null
    }

    private fun registerNetworkListener() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    handler.postDelayed({ if (!settingsOpen && !isPlaying) startPlayback() }, 1500)
                }
                override fun onLost(network: Network) {
                    handler.post { if (!settingsOpen) { isPlaying = false; scheduleProblemOverlay(); scheduleRetry() } }
                }
            }
            cm.registerDefaultNetworkCallback(callback)
            networkCallback = callback
        } catch (_: Exception) { }
    }

    private fun askForPin() {
        if (settingsOpen) return
        val expected = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PIN, "1234") ?: "1234"
        val input = EditText(this).apply { hint = "PIN de administrador"; inputType = 2 }
        AlertDialog.Builder(this).setTitle("Administración ClickTv")
            .setView(input)
            .setPositiveButton("Continuar") { _, _ ->
                if (input.text.toString() == expected) showSettings(false)
                else Toast.makeText(this, "PIN incorrecto", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun showSettings(firstRun: Boolean) {
        settingsOpen = true
        cancelRetry()
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 24, 36, 12)
        }
        fun field(label: String, value: String, hintText: String = ""): EditText {
            container.addView(TextView(this).apply { text = label; setTextColor(Color.WHITE); textSize = 14f; setPadding(0, 10, 0, 4) })
            return EditText(this).apply {
                setText(value); hint = hintText; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
                setSingleLine(true); container.addView(this)
            }
        }
        val urlInput = field("URL de la señal (HLS/M3U8 o SRT)", prefs.getString(KEY_URL, DEFAULT_URL) ?: DEFAULT_URL, "https://...m3u8 o srt://host:puerto")
        val typeInput = field("Tipo de fuente (AUTO, HLS o SRT)", prefs.getString(KEY_TYPE, "HLS") ?: "HLS", "AUTO")
        val pinInput = field("PIN de administrador", prefs.getString(KEY_PIN, "1234") ?: "1234", "1234")
        val delayInput = field("Segundos antes de mostrar PRONTO VOLVEMOS", prefs.getInt(KEY_DELAY, 5).toString(), "5")
        val autoStart = android.widget.CheckBox(this).apply {
            text = "Intentar iniciar automáticamente al encender"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean(KEY_AUTOSTART, false)
            container.addView(this)
        }
        val crop = android.widget.CheckBox(this).apply {
            text = "Recortar imagen para llenar 16:9"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean(KEY_CROP, false)
            container.addView(this)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(container) }
        val dialog = AlertDialog.Builder(this).setTitle("ClickTv Player — Configuración")
            .setView(scroll)
            .setCancelable(!firstRun)
            .setPositiveButton("Guardar y reproducir", null)
            .setNegativeButton(if (firstRun) "Salir" else "Cancelar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val url = urlInput.text.toString().trim()
                if (url.isBlank()) { urlInput.error = "Ingresa una URL"; return@setOnClickListener }
                val type = typeInput.text.toString().trim().uppercase(Locale.ROOT)
                if (type !in listOf("AUTO", "HLS", "SRT")) { typeInput.error = "Usa AUTO, HLS o SRT"; return@setOnClickListener }
                val pin = pinInput.text.toString().ifBlank { "1234" }
                val delay = delayInput.text.toString().toIntOrNull()?.coerceIn(1, 120) ?: 5
                prefs.edit().putString(KEY_URL, url).putString(KEY_TYPE, type).putString(KEY_PIN, pin)
                    .putInt(KEY_DELAY, delay).putBoolean(KEY_AUTOSTART, autoStart.isChecked)
                    .putBoolean(KEY_CROP, crop.isChecked).apply()
                dialog.dismiss()
                settingsOpen = false
                lastUrl = url
                startPlayback()
            }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                dialog.dismiss()
                if (firstRun && prefs.getString(KEY_URL, "").isNullOrBlank()) finish()
                else { settingsOpen = false; startPlayback() }
            }
        }
        dialog.setOnDismissListener { if (settingsOpen && prefs.getString(KEY_URL, "").isNullOrBlank()) settingsOpen = false }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.85).toInt(), (resources.displayMetrics.heightPixels * 0.85).toInt())
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU || (keyCode == KeyEvent.KEYCODE_DPAD_CENTER && event?.isLongPress == true)) {
            askForPin(); return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() { super.onResume(); enterImmersive(); if (!settingsOpen && !isPlaying) scheduleRetry() }

    override fun onDestroy() {
        cancelRetry()
        overlayRunnable?.let { handler.removeCallbacks(it) }
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            networkCallback?.let { cm.unregisterNetworkCallback(it) }
        } catch (_: Exception) { }
        player?.setEventListener(null)
        player?.stop()
        player?.detachViews()
        player?.release()
        player = null
        libVLC?.release()
        libVLC = null
        super.onDestroy()
    }
}
