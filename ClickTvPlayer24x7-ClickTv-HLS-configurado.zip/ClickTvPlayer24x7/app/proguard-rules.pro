# Keep VLC native bindings intact. Minification is disabled for this initial build.
