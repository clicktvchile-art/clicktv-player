# ClickTv Player 24/7 (prototipo inicial de proyecto Android)

Proyecto Kotlin para Android Studio, orientado a TV Box, Android TV y móviles. La fuente inicial predeterminada ya está configurada con el enlace HLS proporcionado para ClickTv Chile. Incluye reproducción mediante LibVLC, pantalla inmersiva, reintentos automáticos, mensaje `PRONTO VOLVEMOS`, panel de configuración y una opción de intento de autoarranque.

## Fuente predeterminada configurada

`https://andromeda2.cd-latam.com:1936/Monitoreo_ClickTV/clicktv.stream/playlist.m3u8`

El proyecto guardará esta fuente como HLS al primer inicio si todavía no existe una URL configurada. La disponibilidad y reproducción efectiva deben verificarse desde el dispositivo y la red de destino.

## Importante: estado de esta entrega

- El código fuente está preparado como punto de partida funcional, pero **no se ha compilado ni probado en un dispositivo en esta sesión**.
- La reproducción SRT depende de las capacidades de SRT incluidas en el artefacto LibVLC seleccionado y de la sintaxis aceptada por esa versión. Verifica una URL SRT real antes de distribuirlo.
- El autoarranque tras reiniciar depende de las restricciones del fabricante y la versión de Android. En algunos dispositivos será necesario seleccionar la app como launcher o configurar el inicio automático en los ajustes del fabricante.
- El panel inicial permite configurar URL, tipo AUTO/HLS/SRT, PIN, tiempo del mensaje, recorte y autoarranque. La interfaz de ajustes es intencionalmente sencilla para priorizar la lógica del reproductor.

## Compilar

1. Instala Android Studio estable y un JDK 17.
2. Abre esta carpeta como proyecto existente.
3. Permite que Gradle sincronice dependencias. Se necesita acceso a Internet para descargar dependencias.
4. Instala Android SDK Platform 35 y las herramientas solicitadas por Android Studio.
5. Ejecuta `Build > Make Project`.
6. Para generar APK de prueba: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
7. El APK de depuración suele quedar en `app/build/outputs/apk/debug/app-debug.apk` después de compilar correctamente.

## Uso

1. Instala y abre la aplicación.
2. En el primer inicio intentará reproducir la fuente HLS predeterminada de ClickTv Chile.
3. Para cambiar la fuente, abre el panel de configuración y selecciona AUTO, HLS o SRT.
4. PIN predeterminado: `1234` (cámbialo desde el panel).
5. Pulsa Guardar y reproducir.
6. Para abrir la configuración, mantén pulsada la superficie del reproductor o utiliza la tecla MENU del mando y escribe el PIN.

## Pruebas necesarias antes de producción

- Verificar M3U8/HLS en los modelos concretos de TV Box.
- Verificar SRT con una fuente real, incluyendo caller/listener y passphrase si se requieren.
- Probar desconexión y reconexión de red repetidas veces.
- Probar autoarranque en cada modelo de dispositivo.
- Revisar licencias y obligaciones de redistribución de LibVLC antes de distribuir el APK.

## Limitaciones conocidas de esta primera base

- No se proporciona un APK precompilado porque no se ha ejecutado una compilación verificable.
- La configuración SRT avanzada (modo, latencia, passphrase) todavía requiere completar la interfaz y mapear sus parámetros al motor.
- La recuperación se basa en eventos de LibVLC; se recomienda añadir pruebas instrumentadas y un detector de progreso de vídeo antes de uso de emisión 24/7.
- `BOOT_COMPLETED` no garantiza que Android permita abrir una actividad automáticamente en todos los fabricantes.
